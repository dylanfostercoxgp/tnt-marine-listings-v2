<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* =========================================================================
   Recognised filter query params — used for cache bypass and sanitization
   ========================================================================= */
function tnt_marine_filter_param_keys(): array {
    return [
        'tnt_sort',
        'tnt_make',
        'tnt_price_min', 'tnt_price_max',
        'tnt_length_min', 'tnt_length_max',
        'tnt_year_min', 'tnt_year_max',
        'tnt_hours_max',
        'tnt_ts',        // cache-buster emitted by tnt-marine-filter.js on Apply
        'tnt_debug', 'tnt_nocache',
    ];
}

/**
 * Tell every major page cache NOT to cache the response when any filter is in
 * the URL. Without this, WP Rocket / LiteSpeed / WP Super Cache / W3TC /
 * Cloudflare / SG Optimizer serve the same stale HTML regardless of ?tnt_make=.
 *
 * Runs very early (init priority 1) so it beats cache plugins' output buffers.
 */
add_action( 'init', function () {
    $active = false;
    foreach ( tnt_marine_filter_param_keys() as $key ) {
        if ( isset( $_GET[ $key ] ) && $_GET[ $key ] !== '' ) {
            $active = true;
            break;
        }
    }
    if ( ! $active ) return;

    if ( ! defined( 'DONOTCACHEPAGE' ) )   define( 'DONOTCACHEPAGE',   true );
    if ( ! defined( 'DONOTCACHEOBJECT' ) ) define( 'DONOTCACHEOBJECT', true );
    if ( ! defined( 'DONOTCACHEDB' ) )     define( 'DONOTCACHEDB',     true );
    if ( ! defined( 'DONOTMINIFY' ) )      define( 'DONOTMINIFY',      true );

    // Ask WP to emit no-cache headers.
    if ( function_exists( 'nocache_headers' ) ) nocache_headers();

    // Belt-and-braces: direct response headers for Varnish / Cloudflare / nginx
    // page cache / reverse proxies that don't honor WordPress constants.
    if ( ! headers_sent() ) {
        header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
        header( 'Pragma: no-cache' );
        header( 'Expires: 0' );
    }
}, 1 );

// Tell LiteSpeed Cache specifically to skip caching.
add_action( 'litespeed_control_set_nocache', function ( $reason ) {
    return $reason ?: 'tnt-marine-filter';
} );
add_filter( 'litespeed_cache_control_no_cache', function ( $no ) {
    foreach ( tnt_marine_filter_param_keys() as $key ) {
        if ( isset( $_GET[ $key ] ) && $_GET[ $key ] !== '' ) return true;
    }
    return $no;
} );

/* =========================================================================
   Shared card renderer (used by both shortcodes)
   ========================================================================= */

function tnt_marine_render_card( $pid, $opts = [] ) {
    $settings = tnt_marine_get_settings();
    $price    = get_post_meta( $pid, '_tnt_price',    true );
    $year     = get_post_meta( $pid, '_tnt_year',     true );
    $length   = get_post_meta( $pid, '_tnt_length',   true );
    $hours    = get_post_meta( $pid, '_tnt_hours',    true );
    $location = get_post_meta( $pid, '_tnt_location', true );
    $sold     = get_post_meta( $pid, '_tnt_sold',     true );

    $thumb_id = (int) get_post_thumbnail_id( $pid );
    if ( ! $thumb_id ) {
        $gallery_ids = get_post_meta( $pid, '_tnt_gallery_ids', true );
        if ( $gallery_ids ) {
            $ids      = array_filter( array_map( 'intval', explode( ',', $gallery_ids ) ) );
            $thumb_id = reset( $ids );
        }
    }
    $img_url = $thumb_id
        ? wp_get_attachment_image_url( $thumb_id, 'large' )
        : TNT_MARINE_URL . 'assets/img/placeholder.jpg';

    $show_sold_badge = ! empty( $opts['show_sold_badge'] );
    $badge_text  = esc_html( $settings['sold_badge_text'] ?: 'SOLD' );
    $badge_color = esc_attr( $settings['sold_badge_color'] ?: '#cc2129' );

    // Filter-able data attributes — the client-side filter uses these.
    $card_brand = tnt_marine_listing_brand( (int) $pid );
    $date_ts    = get_post_time( 'U', true, $pid );
    ?>
    <a class="tnt-card"
       href="<?php the_permalink(); ?>"
       data-brand="<?php echo esc_attr( strtolower( $card_brand ) ); ?>"
       data-brand-display="<?php echo esc_attr( $card_brand ); ?>"
       data-price="<?php echo esc_attr( is_numeric( $price ) ? (float) $price : '' ); ?>"
       data-year="<?php echo esc_attr( is_numeric( $year ) ? (int) $year : '' ); ?>"
       data-length="<?php echo esc_attr( is_numeric( $length ) ? (float) $length : '' ); ?>"
       data-hours="<?php echo esc_attr( is_numeric( $hours ) ? (float) $hours : '' ); ?>"
       data-sold="<?php echo esc_attr( $sold === '1' ? '1' : '0' ); ?>"
       data-date="<?php echo esc_attr( (int) $date_ts ); ?>">
        <div class="tnt-card-image" style="background-image:url('<?php echo esc_url( $img_url ); ?>')">
            <?php if ( $show_sold_badge ) : ?>
                <span class="tnt-sold-badge" style="background:<?php echo $badge_color; ?>;"><?php echo $badge_text; ?></span>
            <?php endif; ?>
        </div>
        <div class="tnt-card-body">
            <h3 class="tnt-card-title"><?php the_title(); ?></h3>
            <?php if ( $location && $settings['show_location'] ) : ?>
                <p class="tnt-card-location"><?php echo esc_html( $location ); ?></p>
            <?php endif; ?>
            <div class="tnt-card-specs">
                <?php if ( $year   && $settings['show_year']   ) : ?><span><?php echo esc_html( $year ); ?></span><?php endif; ?>
                <?php if ( $length && $settings['show_length'] ) : ?><span><?php echo esc_html( $length ); ?>ft</span><?php endif; ?>
            </div>
            <?php if ( $price && $settings['show_price'] && empty( $opts['hide_price'] ) ) : ?>
                <p class="tnt-card-price">$<?php echo number_format( floatval( $price ) ); ?></p>
            <?php endif; ?>
        </div>
    </a>
    <?php
}

/* =========================================================================
   [marine_listings] – Active inventory
   Usage: [marine_listings per_page="12"]
   ========================================================================= */

function tnt_marine_listings_shortcode( $atts ) {
    $settings = tnt_marine_get_settings();
    $atts     = shortcode_atts( [ 'per_page' => intval( $settings['listings_per_page'] ) ?: 12 ], $atts, 'marine_listings' );

    // The filter/sort work CLIENT-SIDE so page caching, CDNs, reverse proxies,
    // and page builders can't prevent filtering. We render every active listing
    // once with data-* attributes; JS in tnt-marine-filter.js hides non-matches.
    $query_args = [
        'post_type'      => 'marine_listing',
        'post_status'    => 'publish',
        'posts_per_page' => 500,
        'orderby'        => 'meta_value_num',
        'meta_key'       => '_tnt_year',
        'order'          => 'DESC',
        'meta_query'     => [
            'relation' => 'OR',
            [ 'key' => '_tnt_sold', 'compare' => '!=',         'value' => '1' ],
            [ 'key' => '_tnt_sold', 'compare' => 'NOT EXISTS' ],
        ],
        'no_found_rows'  => true,
        'cache_results'  => false,
    ];

    $query         = new WP_Query( $query_args );
    $brand_options = tnt_marine_get_brand_options( false );
    $current_url   = strtok( $_SERVER['REQUEST_URI'], '?' );

    // Version marker so we can verify the right code is running.
    printf( "\n<!-- TNT Marine %s | client-side filter | listings=%d -->\n",
        esc_html( defined( 'TNT_MARINE_VERSION' ) ? TNT_MARINE_VERSION : '?' ),
        (int) $query->found_posts
    );

    $per_page = max( 1, intval( $atts['per_page'] ) );

    ob_start();
    ?>
    <div class="tnt-listings-wrap"
         data-tnt-filter="1"
         data-per-page="<?php echo esc_attr( $per_page ); ?>"
         data-shortcode="marine_listings">

        <div class="tnt-filter-bar">
            <div class="tnt-filter-row">

                <div class="tnt-filter-group tnt-filter-group--single">
                    <label>Brand</label>
                    <select id="tnt_make" class="tnt-filter-select">
                        <option value="">All Brands</option>
                        <?php foreach ( $brand_options as $b ) : ?>
                            <option value="<?php echo esc_attr( $b ); ?>"><?php echo esc_html( $b ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="tnt-filter-group">
                    <label>Price ($)</label>
                    <div class="tnt-filter-range">
                        <input type="number" id="tnt_price_min" placeholder="Min" min="0" step="1000">
                        <span class="tnt-range-sep">to</span>
                        <input type="number" id="tnt_price_max" placeholder="Max" min="0" step="1000">
                    </div>
                </div>

                <div class="tnt-filter-group">
                    <label>Length (ft)</label>
                    <div class="tnt-filter-range">
                        <input type="number" id="tnt_length_min" placeholder="Min" min="0">
                        <span class="tnt-range-sep">to</span>
                        <input type="number" id="tnt_length_max" placeholder="Max" min="0">
                    </div>
                </div>

                <div class="tnt-filter-group">
                    <label>Year</label>
                    <div class="tnt-filter-range">
                        <input type="number" id="tnt_year_min" placeholder="From" min="1900" max="2100">
                        <span class="tnt-range-sep">to</span>
                        <input type="number" id="tnt_year_max" placeholder="To" min="1900" max="2100">
                    </div>
                </div>

                <div class="tnt-filter-group tnt-filter-group--single">
                    <label>Max Engine Hours</label>
                    <input type="number" id="tnt_hours_max" placeholder="e.g. 500" min="0">
                </div>

                <div class="tnt-filter-actions">
                    <button type="button" id="tnt-apply-filters" class="tnt-btn-filter-apply">Apply</button>
                    <button type="button" id="tnt-clear-filters" class="tnt-btn-filter-reset" style="display:none;">Clear</button>
                </div>

            </div>
            <p class="tnt-filter-active-notice" style="display:none;">
                Filters active &mdash; <a href="#" class="tnt-clear-link">view all listings</a>
            </p>
        </div>

        <?php echo tnt_marine_sort_bar( 'year_desc', (int) $query->found_posts ); ?>

        <?php if ( $query->have_posts() ) : ?>
            <div class="tnt-listings-grid" id="tnt-listings-grid">
                <?php while ( $query->have_posts() ) : $query->the_post();
                    tnt_marine_render_card( get_the_ID() );
                endwhile; wp_reset_postdata(); ?>
            </div>
            <div class="tnt-no-listings" id="tnt-no-match" style="display:none;">
                No listings match your current filters. <a href="#" class="tnt-clear-link">Clear filters</a> to see all listings.
            </div>
            <div class="tnt-pagination" id="tnt-pagination" style="display:none;"></div>
        <?php else : ?>
            <p class="tnt-no-listings">No listings available.</p>
        <?php endif; ?>

    </div>
    <?php
    echo tnt_marine_footer_render();
    return ob_get_clean();
}
add_shortcode( 'marine_listings', 'tnt_marine_listings_shortcode' );

/* =========================================================================
   [marine_sold_listings] – Sold inventory
   Usage: [marine_sold_listings per_page="12"]
   Identical layout to active listings but:
     • Only shows listings where _tnt_sold = 1
     • No price filter (price filter removed as requested)
     • SOLD badge overlaid on every card image
   ========================================================================= */

function tnt_marine_sold_listings_shortcode( $atts ) {
    $settings = tnt_marine_get_settings();
    $atts     = shortcode_atts( [ 'per_page' => intval( $settings['sold_per_page'] ) ?: 12 ], $atts, 'marine_sold_listings' );

    // Only sold listings — render everything, client-side filters the rest.
    $query_args = [
        'post_type'      => 'marine_listing',
        'post_status'    => 'publish',
        'posts_per_page' => 500,
        'orderby'        => 'meta_value_num',
        'meta_key'       => '_tnt_year',
        'order'          => 'DESC',
        'meta_query'     => [
            [ 'key' => '_tnt_sold', 'compare' => '=', 'value' => '1' ],
        ],
        'no_found_rows'  => true,
        'cache_results'  => false,
    ];

    $query         = new WP_Query( $query_args );
    $brand_options = tnt_marine_get_brand_options( true );
    $per_page      = max( 1, intval( $atts['per_page'] ) );

    printf( "\n<!-- TNT Marine %s | client-side filter (sold) | listings=%d -->\n",
        esc_html( defined( 'TNT_MARINE_VERSION' ) ? TNT_MARINE_VERSION : '?' ),
        (int) $query->found_posts
    );

    ob_start();
    ?>
    <div class="tnt-listings-wrap"
         data-tnt-filter="1"
         data-per-page="<?php echo esc_attr( $per_page ); ?>"
         data-shortcode="marine_sold_listings">

        <!-- Filter bar – price filter deliberately omitted for sold listings -->
        <div class="tnt-filter-bar">
            <div class="tnt-filter-row">

                <div class="tnt-filter-group tnt-filter-group--single">
                    <label>Brand</label>
                    <select id="tnt_make" class="tnt-filter-select">
                        <option value="">All Brands</option>
                        <?php foreach ( $brand_options as $b ) : ?>
                            <option value="<?php echo esc_attr( $b ); ?>"><?php echo esc_html( $b ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="tnt-filter-group">
                    <label>Length (ft)</label>
                    <div class="tnt-filter-range">
                        <input type="number" id="tnt_length_min" placeholder="Min" min="0">
                        <span class="tnt-range-sep">to</span>
                        <input type="number" id="tnt_length_max" placeholder="Max" min="0">
                    </div>
                </div>

                <div class="tnt-filter-group">
                    <label>Year</label>
                    <div class="tnt-filter-range">
                        <input type="number" id="tnt_year_min" placeholder="From" min="1900" max="2100">
                        <span class="tnt-range-sep">to</span>
                        <input type="number" id="tnt_year_max" placeholder="To" min="1900" max="2100">
                    </div>
                </div>

                <div class="tnt-filter-group tnt-filter-group--single">
                    <label>Max Engine Hours</label>
                    <input type="number" id="tnt_hours_max" placeholder="e.g. 500" min="0">
                </div>

                <div class="tnt-filter-actions">
                    <button type="button" id="tnt-apply-filters" class="tnt-btn-filter-apply">Apply</button>
                    <button type="button" id="tnt-clear-filters" class="tnt-btn-filter-reset" style="display:none;">Clear</button>
                </div>

            </div>
            <p class="tnt-filter-active-notice" style="display:none;">
                Filters active &mdash; <a href="#" class="tnt-clear-link">view all sold listings</a>
            </p>
        </div>

        <?php echo tnt_marine_sort_bar( 'year_desc', (int) $query->found_posts ); ?>

        <?php if ( $query->have_posts() ) : ?>
            <div class="tnt-listings-grid" id="tnt-listings-grid">
                <?php while ( $query->have_posts() ) : $query->the_post();
                    tnt_marine_render_card( get_the_ID(), [ 'show_sold_badge' => true ] );
                endwhile; wp_reset_postdata(); ?>
            </div>
            <div class="tnt-no-listings" id="tnt-no-match" style="display:none;">
                No sold listings match your current filters. <a href="#" class="tnt-clear-link">Clear filters</a> to see all sold listings.
            </div>
            <div class="tnt-pagination" id="tnt-pagination" style="display:none;"></div>
        <?php else : ?>
            <p class="tnt-no-listings">No sold listings available.</p>
        <?php endif; ?>

    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'marine_sold_listings', 'tnt_marine_sold_listings_shortcode' );

/* =========================================================================
   Shared helpers
   ========================================================================= */

function tnt_marine_sort_args( string $sort ): array {
    // Default: Year Newest First — matches the default sort option shown in the sort bar.
    $orderby  = 'meta_value_num';
    $order    = 'DESC';
    $meta_key = '_tnt_year';
    switch ( $sort ) {
        case 'date_desc':   $orderby = 'date';           $meta_key = '';            $order = 'DESC'; break;
        case 'price_asc':   $orderby = 'meta_value_num'; $meta_key = '_tnt_price';  $order = 'ASC';  break;
        case 'price_desc':  $orderby = 'meta_value_num'; $meta_key = '_tnt_price';  $order = 'DESC'; break;
        case 'year_asc':    $orderby = 'meta_value_num'; $meta_key = '_tnt_year';   $order = 'ASC';  break;
        case 'year_desc':   $orderby = 'meta_value_num'; $meta_key = '_tnt_year';   $order = 'DESC'; break;
        case 'length_asc':  $orderby = 'meta_value_num'; $meta_key = '_tnt_length'; $order = 'ASC';  break;
        case 'length_desc': $orderby = 'meta_value_num'; $meta_key = '_tnt_length'; $order = 'DESC'; break;
    }
    return [ $orderby, $order, $meta_key ];
}

function tnt_marine_sort_bar( string $sort, int $found ): string {
    ob_start();
    ?>
    <div class="tnt-sort-bar">
        <label for="tnt-sort-select">Sort By:</label>
        <select id="tnt-sort-select">
            <option value="year_desc"   <?php selected( $sort, 'year_desc' ); ?>>Year: Newest First</option>
            <option value="year_asc"    <?php selected( $sort, 'year_asc' ); ?>>Year: Oldest First</option>
            <option value="date_desc"   <?php selected( $sort, 'date_desc' ); ?>>Newest Listed</option>
            <option value="price_asc"   <?php selected( $sort, 'price_asc' ); ?>>Price: Low to High</option>
            <option value="price_desc"  <?php selected( $sort, 'price_desc' ); ?>>Price: High to Low</option>
            <option value="length_asc"  <?php selected( $sort, 'length_asc' ); ?>>Length: Shortest First</option>
            <option value="length_desc" <?php selected( $sort, 'length_desc' ); ?>>Length: Longest First</option>
        </select>
        <span class="tnt-result-count"><?php echo intval( $found ); ?> listing<?php echo $found !== 1 ? 's' : ''; ?></span>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Returns a deduped, alphabetically sorted list of distinct Brand / Make values
 * for published marine_listing posts.
 *
 * Preference order for where the brand comes from, per listing:
 *   1. _tnt_make meta value (explicitly set)
 *   2. Parsed from the post title (skip leading year, take words until a
 *      number-leading word appears — covers "2023 Sea Ray 390 Sport",
 *      "2024 Grady-White 336", "2025 Yamaha 252 SE", etc.)
 *   3. First word(s) of _tnt_model (last-resort fallback)
 *
 * Cached for 10 minutes to keep the listings page fast. The cache is cleared
 * automatically on any marine_listing save.
 *
 * @param bool $sold_only  When true, limit to listings flagged as sold.
 * @return string[]
 */
function tnt_marine_get_brand_options( bool $sold_only = false ): array {
    $cache_key = 'tnt_marine_brand_options_' . ( $sold_only ? 'sold' : 'active' );
    $cached    = get_transient( $cache_key );
    if ( is_array( $cached ) ) return $cached;

    $args = [
        'post_type'      => 'marine_listing',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'meta_query'     => [
            [
                'key'     => '_tnt_sold',
                'compare' => $sold_only ? '=' : '!=',
                'value'   => '1',
            ],
        ],
    ];

    $ids = get_posts( $args );
    if ( empty( $ids ) ) {
        set_transient( $cache_key, [], 10 * MINUTE_IN_SECONDS );
        return [];
    }

    $seen   = [];
    $brands = [];
    foreach ( $ids as $pid ) {
        $brand = tnt_marine_listing_brand( (int) $pid );
        if ( $brand === '' ) continue;
        $key = strtolower( $brand );
        if ( isset( $seen[ $key ] ) ) continue;
        $seen[ $key ] = true;
        $brands[]     = $brand;
    }

    sort( $brands, SORT_NATURAL | SORT_FLAG_CASE );
    set_transient( $cache_key, $brands, 10 * MINUTE_IN_SECONDS );
    return $brands;
}

/**
 * Returns the best available brand string for a single listing.
 * Tries _tnt_make first, then parses the post title, then falls back to
 * the first word of _tnt_model. Returns '' if nothing usable is found.
 */
function tnt_marine_listing_brand( int $post_id ): string {
    $make = trim( (string) get_post_meta( $post_id, '_tnt_make', true ) );
    if ( $make !== '' ) return $make;

    $title = trim( (string) get_the_title( $post_id ) );
    $brand = tnt_marine_parse_brand_from_title( $title );
    if ( $brand !== '' ) return $brand;

    $model = trim( (string) get_post_meta( $post_id, '_tnt_model', true ) );
    if ( $model !== '' ) {
        // Take leading non-digit tokens (e.g., "390 Sport" -> ''; "Sea Ray 390" -> "Sea Ray").
        $parts = preg_split( '/\s+/', $model );
        $pick  = [];
        foreach ( $parts as $w ) {
            if ( $w === '' ) continue;
            if ( preg_match( '/^\d/', $w ) ) break;
            $pick[] = $w;
            if ( count( $pick ) >= 2 ) break;
        }
        if ( ! empty( $pick ) ) return implode( ' ', $pick );
    }
    return '';
}

/**
 * Parses a brand out of a listing title like:
 *   "2023 Sea Ray 390 Sport Center Console" -> "Sea Ray"
 *   "2024 Grady-White 336 Canyon"           -> "Grady-White"
 *   "2025 Yamaha 252 SE"                    -> "Yamaha"
 *   "2022 Boston Whaler 380 Outrage"        -> "Boston Whaler"
 *
 * Strategy: skip a leading 4-digit year, then take words until we hit a word
 * that starts with a digit (which is where the model number begins).
 */
function tnt_marine_parse_brand_from_title( string $title ): string {
    $title = trim( preg_replace( '/\s+/', ' ', $title ) );
    if ( $title === '' ) return '';

    $parts = explode( ' ', $title );
    // Drop a leading year (19xx or 20xx).
    if ( isset( $parts[0] ) && preg_match( '/^(19|20)\d{2}$/', $parts[0] ) ) {
        array_shift( $parts );
    }

    $brand_words = [];
    foreach ( $parts as $w ) {
        if ( $w === '' ) continue;
        // Stop at the model-number token (starts with a digit, e.g. "390", "252").
        if ( preg_match( '/^\d/', $w ) ) break;
        $brand_words[] = $w;
        // Cap at 3 words — "Boston Whaler", "Grady-White", "Sea Ray", etc.
        if ( count( $brand_words ) >= 3 ) break;
    }
    return implode( ' ', $brand_words );
}

/**
 * Builds a meta_query clause that matches a selected brand against either the
 * _tnt_make meta OR a leading-word match on the post title / _tnt_model.
 *
 * Using WordPress's meta_query is not sufficient because we also need to check
 * post_title. Instead, we expand the brand to a list of post IDs and pass those
 * to WP_Query via post__in.
 */
function tnt_marine_ids_matching_brand( string $brand, bool $sold_only = false ): array {
    $brand = trim( $brand );
    if ( $brand === '' ) return [];

    $args = [
        'post_type'      => 'marine_listing',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'meta_query'     => [
            [
                'key'     => '_tnt_sold',
                'compare' => $sold_only ? '=' : '!=',
                'value'   => '1',
            ],
        ],
    ];
    $all_ids = get_posts( $args );
    if ( empty( $all_ids ) ) return [];

    $lower = strtolower( $brand );
    $match = [];
    foreach ( $all_ids as $pid ) {
        $b = strtolower( tnt_marine_listing_brand( (int) $pid ) );
        if ( $b === $lower ) $match[] = (int) $pid;
    }
    return $match;
}

/**
 * Visible debug panel, shown when the URL contains ?tnt_debug=1.
 * Renders above the filter bar with all parsed filter values, the exact
 * WP_Query args used, and the IDs of matched posts so we can pinpoint
 * exactly where the filter chain is going wrong.
 */
function tnt_marine_filter_debug_panel( array $info ): string {
    $version   = defined( 'TNT_MARINE_VERSION' ) ? TNT_MARINE_VERSION : 'unknown';
    $get_dump  = htmlspecialchars( print_r( $_GET, true ), ENT_QUOTES );
    $args_dump = htmlspecialchars( print_r( $info['query_args'] ?? [], true ), ENT_QUOTES );
    $ids       = implode( ', ', array_map( 'intval', $info['matched_ids_preview'] ?? [] ) );

    $rows = [
        'Plugin version'       => esc_html( $version ),
        'Shortcode'            => esc_html( $info['shortcode'] ?? '' ),
        'Request URI'          => esc_html( $_SERVER['REQUEST_URI'] ?? '' ),
        'Parsed brand (make)'  => esc_html( (string) ( $info['make']       ?? '' ) ),
        'Price min / max'      => esc_html( (string) ( $info['price_min']  ?? '' ) . ' / ' . (string) ( $info['price_max']  ?? '' ) ),
        'Length min / max'     => esc_html( (string) ( $info['length_min'] ?? '' ) . ' / ' . (string) ( $info['length_max'] ?? '' ) ),
        'Year min / max'       => esc_html( (string) ( $info['year_min']   ?? '' ) . ' / ' . (string) ( $info['year_max']   ?? '' ) ),
        'Hours max'            => esc_html( (string) ( $info['hours_max']  ?? '' ) ),
        'Sort'                 => esc_html( $info['sort']                   ?? '' ),
        'WP_Query found'       => (string) intval( $info['found']           ?? 0 ),
        'Matched IDs (first 10)' => esc_html( $ids ),
    ];

    ob_start();
    ?>
    <div style="background:#fffbe6;border:2px solid #cc2129;border-radius:8px;padding:16px 20px;margin:0 0 16px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px;line-height:1.5;">
        <div style="font-weight:700;font-size:14px;color:#cc2129;margin-bottom:10px;">TNT Marine Filter Debug</div>
        <table style="width:100%;border-collapse:collapse;">
            <?php foreach ( $rows as $k => $v ) : ?>
                <tr>
                    <td style="padding:4px 10px 4px 0;color:#555;white-space:nowrap;vertical-align:top;"><?php echo esc_html( $k ); ?></td>
                    <td style="padding:4px 0;color:#111;"><?php echo $v === '' ? '<em style="color:#999;">(empty)</em>' : $v; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <details style="margin-top:10px;">
            <summary style="cursor:pointer;color:#555;font-weight:600;">$_GET</summary>
            <pre style="background:#fff;border:1px solid #eee;padding:10px;overflow:auto;margin:6px 0 0;max-height:200px;"><?php echo $get_dump; ?></pre>
        </details>
        <details style="margin-top:6px;">
            <summary style="cursor:pointer;color:#555;font-weight:600;">WP_Query args</summary>
            <pre style="background:#fff;border:1px solid #eee;padding:10px;overflow:auto;margin:6px 0 0;max-height:300px;"><?php echo $args_dump; ?></pre>
        </details>
        <p style="margin:10px 0 0;color:#555;font-size:12px;">
            If "WP_Query found" equals the total listing count while a filter is set, the PHP is running but not filtering.
            If "Parsed brand" is empty while you selected a brand, the URL parameter isn't reaching PHP (page cache or param stripping).
        </p>
    </div>
    <?php
    return ob_get_clean();
}

// Clear the brand-options cache whenever a listing is saved, deleted, or trashed.
add_action( 'save_post_marine_listing', function () {
    delete_transient( 'tnt_marine_brand_options_active' );
    delete_transient( 'tnt_marine_brand_options_sold' );
} );
add_action( 'deleted_post', function ( $pid ) {
    if ( get_post_type( $pid ) === 'marine_listing' ) {
        delete_transient( 'tnt_marine_brand_options_active' );
        delete_transient( 'tnt_marine_brand_options_sold' );
    }
} );
add_action( 'trashed_post', function ( $pid ) {
    if ( get_post_type( $pid ) === 'marine_listing' ) {
        delete_transient( 'tnt_marine_brand_options_active' );
        delete_transient( 'tnt_marine_brand_options_sold' );
    }
} );

function tnt_marine_pagination( int $paged, int $max_pages ): string {
    if ( $max_pages <= 1 ) return '';
    $big = 999999;
    ob_start();
    echo '<div class="tnt-pagination">';
    echo paginate_links( [
        'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
        'format'  => '?paged=%#%',
        'current' => $paged,
        'total'   => $max_pages,
    ] );
    echo '</div>';
    return ob_get_clean();
}
