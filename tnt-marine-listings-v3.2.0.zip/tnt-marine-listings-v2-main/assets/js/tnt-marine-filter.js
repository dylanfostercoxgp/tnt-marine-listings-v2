/* TNT Marine Listings — Client-side filter & sort
 * -------------------------------------------------
 * All matching listings are rendered once by PHP with data-* attributes.
 * This script hides/shows/reorders them in the browser, so page caches,
 * CDNs, reverse proxies, and page builders can never block filtering.
 *
 * No dependencies (vanilla JS). Self-initializes. Safe to load multiple times.
 */
(function () {
    'use strict';

    if (window.__tntMarineFilterLoaded) return;
    window.__tntMarineFilterLoaded = true;

    function num(v) {
        if (v === null || v === undefined || v === '') return NaN;
        var n = parseFloat(v);
        return isNaN(n) ? NaN : n;
    }

    function readFilters(wrap) {
        function val(id) {
            var el = wrap.querySelector('#' + id);
            return el ? String(el.value || '').trim() : '';
        }
        return {
            make: val('tnt_make').toLowerCase(),
            priceMin:  num(val('tnt_price_min')),
            priceMax:  num(val('tnt_price_max')),
            lengthMin: num(val('tnt_length_min')),
            lengthMax: num(val('tnt_length_max')),
            yearMin:   num(val('tnt_year_min')),
            yearMax:   num(val('tnt_year_max')),
            hoursMax:  num(val('tnt_hours_max')),
            sort:      (function () {
                var s = wrap.querySelector('#tnt-sort-select');
                return s ? s.value : 'year_desc';
            })()
        };
    }

    function cardMatches(card, f) {
        if (f.make) {
            var b = (card.getAttribute('data-brand') || '').toLowerCase();
            if (b !== f.make) return false;
        }
        var price  = num(card.getAttribute('data-price'));
        var len    = num(card.getAttribute('data-length'));
        var year   = num(card.getAttribute('data-year'));
        var hours  = num(card.getAttribute('data-hours'));

        if (!isNaN(f.priceMin)  && (isNaN(price) || price < f.priceMin)) return false;
        if (!isNaN(f.priceMax)  && (isNaN(price) || price > f.priceMax)) return false;
        if (!isNaN(f.lengthMin) && (isNaN(len)   || len   < f.lengthMin)) return false;
        if (!isNaN(f.lengthMax) && (isNaN(len)   || len   > f.lengthMax)) return false;
        if (!isNaN(f.yearMin)   && (isNaN(year)  || year  < f.yearMin))  return false;
        if (!isNaN(f.yearMax)   && (isNaN(year)  || year  > f.yearMax))  return false;
        if (!isNaN(f.hoursMax)  && !isNaN(hours) && hours > f.hoursMax)  return false;
        return true;
    }

    function sortCards(cards, sort) {
        var by = 'year', asc = false;
        switch (sort) {
            case 'year_asc':    by = 'year';   asc = true;  break;
            case 'year_desc':   by = 'year';   asc = false; break;
            case 'price_asc':   by = 'price';  asc = true;  break;
            case 'price_desc':  by = 'price';  asc = false; break;
            case 'length_asc':  by = 'length'; asc = true;  break;
            case 'length_desc': by = 'length'; asc = false; break;
            case 'date_desc':   by = 'date';   asc = false; break;
            default:            by = 'year';   asc = false; break;
        }
        return cards.sort(function (a, b) {
            var av = num(a.getAttribute('data-' + by));
            var bv = num(b.getAttribute('data-' + by));
            if (isNaN(av) && isNaN(bv)) return 0;
            if (isNaN(av)) return 1;
            if (isNaN(bv)) return -1;
            return asc ? (av - bv) : (bv - av);
        });
    }

    function applyFilters(wrap) {
        var grid = wrap.querySelector('#tnt-listings-grid, .tnt-listings-grid');
        if (!grid) return;

        var cards = Array.prototype.slice.call(grid.querySelectorAll('.tnt-card'));
        if (!cards.length) return;

        var f = readFilters(wrap);
        var perPage = parseInt(wrap.getAttribute('data-per-page'), 10) || 12;
        var page = parseInt(wrap.getAttribute('data-current-page'), 10) || 1;

        // Match
        var visible = [];
        cards.forEach(function (c) {
            if (cardMatches(c, f)) visible.push(c);
            else c.style.display = 'none';
        });

        // Sort (mutates visible)
        sortCards(visible, f.sort);

        // Re-insert in new order
        visible.forEach(function (c) { grid.appendChild(c); });

        // Pagination (client-side)
        var totalPages = Math.max(1, Math.ceil(visible.length / perPage));
        if (page > totalPages) page = 1;
        wrap.setAttribute('data-current-page', String(page));

        var start = (page - 1) * perPage;
        var end   = start + perPage;
        visible.forEach(function (c, i) {
            c.style.display = (i >= start && i < end) ? '' : 'none';
        });

        // Update result count
        var countEl = wrap.querySelector('.tnt-result-count');
        if (countEl) {
            countEl.textContent = visible.length + ' listing' + (visible.length === 1 ? '' : 's');
        }

        // No-match message
        var noMatch = wrap.querySelector('#tnt-no-match');
        if (noMatch) noMatch.style.display = visible.length === 0 ? '' : 'none';

        // Active-filter hints (Clear button + notice)
        var anyActive = !!f.make
            || !isNaN(f.priceMin)  || !isNaN(f.priceMax)
            || !isNaN(f.lengthMin) || !isNaN(f.lengthMax)
            || !isNaN(f.yearMin)   || !isNaN(f.yearMax)
            || !isNaN(f.hoursMax);
        var clearBtn = wrap.querySelector('#tnt-clear-filters');
        if (clearBtn) clearBtn.style.display = anyActive ? '' : 'none';
        var notice = wrap.querySelector('.tnt-filter-active-notice');
        if (notice) notice.style.display = anyActive ? '' : 'none';

        renderPagination(wrap, page, totalPages);

        // Reflect filters in the URL (bookmarkable) without reloading.
        try {
            var url = new URL(window.location.href);
            [
                ['tnt_make',       f.make],
                ['tnt_price_min',  isNaN(f.priceMin)  ? '' : String(f.priceMin)],
                ['tnt_price_max',  isNaN(f.priceMax)  ? '' : String(f.priceMax)],
                ['tnt_length_min', isNaN(f.lengthMin) ? '' : String(f.lengthMin)],
                ['tnt_length_max', isNaN(f.lengthMax) ? '' : String(f.lengthMax)],
                ['tnt_year_min',   isNaN(f.yearMin)   ? '' : String(f.yearMin)],
                ['tnt_year_max',   isNaN(f.yearMax)   ? '' : String(f.yearMax)],
                ['tnt_hours_max',  isNaN(f.hoursMax)  ? '' : String(f.hoursMax)],
                ['tnt_sort',       f.sort === 'year_desc' ? '' : f.sort]
            ].forEach(function (p) {
                if (p[1]) url.searchParams.set(p[0], p[1]);
                else      url.searchParams.delete(p[0]);
            });
            url.searchParams.delete('paged');
            url.searchParams.delete('tnt_ts');
            history.replaceState(null, '', url.toString());
        } catch (e) {
            // Fine — non-critical
        }
    }

    function renderPagination(wrap, current, total) {
        var pag = wrap.querySelector('#tnt-pagination');
        if (!pag) return;
        if (total <= 1) { pag.style.display = 'none'; pag.innerHTML = ''; return; }
        var html = '';
        // Prev
        if (current > 1) {
            html += '<a href="#" class="tnt-page" data-page="' + (current - 1) + '">&laquo; Prev</a>';
        }
        for (var i = 1; i <= total; i++) {
            if (i === current) {
                html += '<span class="tnt-page tnt-page-current">' + i + '</span>';
            } else if (i <= 3 || i > total - 3 || Math.abs(i - current) <= 1) {
                html += '<a href="#" class="tnt-page" data-page="' + i + '">' + i + '</a>';
            } else if (i === 4 && current > 5) {
                html += '<span class="tnt-page-ellipsis">&hellip;</span>';
            } else if (i === total - 3 && current < total - 4) {
                html += '<span class="tnt-page-ellipsis">&hellip;</span>';
            }
        }
        if (current < total) {
            html += '<a href="#" class="tnt-page" data-page="' + (current + 1) + '">Next &raquo;</a>';
        }
        pag.innerHTML = html;
        pag.style.display = '';
    }

    function clearFilters(wrap) {
        var ids = ['tnt_make', 'tnt_price_min', 'tnt_price_max', 'tnt_length_min',
                   'tnt_length_max', 'tnt_year_min', 'tnt_year_max', 'tnt_hours_max'];
        ids.forEach(function (id) {
            var el = wrap.querySelector('#' + id);
            if (!el) return;
            if (el.tagName === 'SELECT') el.value = '';
            else el.value = '';
        });
        wrap.setAttribute('data-current-page', '1');
        applyFilters(wrap);
    }

    function initWrap(wrap) {
        if (wrap.__tntInit) return;
        wrap.__tntInit = true;

        // Pre-fill from URL (bookmarkable links), then apply.
        try {
            var url = new URL(window.location.href);
            var set = function (id, v) {
                if (v === null || v === '') return;
                var el = wrap.querySelector('#' + id);
                if (el) el.value = v;
            };
            set('tnt_make',       url.searchParams.get('tnt_make'));
            set('tnt_price_min',  url.searchParams.get('tnt_price_min'));
            set('tnt_price_max',  url.searchParams.get('tnt_price_max'));
            set('tnt_length_min', url.searchParams.get('tnt_length_min'));
            set('tnt_length_max', url.searchParams.get('tnt_length_max'));
            set('tnt_year_min',   url.searchParams.get('tnt_year_min'));
            set('tnt_year_max',   url.searchParams.get('tnt_year_max'));
            set('tnt_hours_max',  url.searchParams.get('tnt_hours_max'));
            var s = url.searchParams.get('tnt_sort');
            if (s) {
                var sel = wrap.querySelector('#tnt-sort-select');
                if (sel) sel.value = s;
            }
        } catch (e) {}

        wrap.setAttribute('data-current-page', '1');

        // Apply on button click
        var applyBtn = wrap.querySelector('#tnt-apply-filters');
        if (applyBtn) {
            applyBtn.addEventListener('click', function (e) {
                e.preventDefault();
                wrap.setAttribute('data-current-page', '1');
                applyFilters(wrap);
            });
        }

        // Clear buttons / links
        wrap.addEventListener('click', function (e) {
            var t = e.target;
            if (!t) return;
            if (t.id === 'tnt-clear-filters' || t.classList.contains('tnt-clear-link')) {
                e.preventDefault();
                clearFilters(wrap);
            }
            // Pagination
            if (t.classList && t.classList.contains('tnt-page') && t.dataset.page) {
                e.preventDefault();
                wrap.setAttribute('data-current-page', t.dataset.page);
                applyFilters(wrap);
                // Scroll to grid
                var grid = wrap.querySelector('.tnt-listings-grid');
                if (grid && grid.scrollIntoView) {
                    grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        });

        // Apply when pressing Enter in any filter input
        wrap.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.keyCode === 13) {
                var t = e.target;
                if (!t || !t.closest) return;
                if (t.closest('.tnt-filter-bar')) {
                    e.preventDefault();
                    wrap.setAttribute('data-current-page', '1');
                    applyFilters(wrap);
                }
            }
        });

        // Sort changes apply immediately
        var sortSel = wrap.querySelector('#tnt-sort-select');
        if (sortSel) {
            sortSel.addEventListener('change', function () {
                wrap.setAttribute('data-current-page', '1');
                applyFilters(wrap);
            });
        }

        // Brand changes apply immediately — feels snappier
        var makeSel = wrap.querySelector('#tnt_make');
        if (makeSel) {
            makeSel.addEventListener('change', function () {
                wrap.setAttribute('data-current-page', '1');
                applyFilters(wrap);
            });
        }

        // Do the initial layout (applies any URL params + starts pagination)
        applyFilters(wrap);
    }

    function init() {
        var wraps = document.querySelectorAll('[data-tnt-filter="1"]');
        for (var i = 0; i < wraps.length; i++) initWrap(wraps[i]);

        // Re-check after a beat in case a page builder mounts content late.
        setTimeout(function () {
            var w2 = document.querySelectorAll('[data-tnt-filter="1"]');
            for (var j = 0; j < w2.length; j++) initWrap(w2[j]);
        }, 500);
        setTimeout(function () {
            var w3 = document.querySelectorAll('[data-tnt-filter="1"]');
            for (var k = 0; k < w3.length; k++) initWrap(w3[k]);
        }, 1500);
    }

    // Back-compat no-op shim so old inline onchange on cached pages doesn't error
    window.tntSortChange = function () {};

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
